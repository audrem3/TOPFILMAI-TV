# TopFilmaiTV - Android TV Leanback Projektas

Sveikiname! Tai yra pilnas, paruoštas gamyklinis **Android Studio** pirminis kodas jūsų Formuler Z12 Ultra priedėliui.

## 🚀 AUTOMATINIS NEMOKAMAS APK KOMPILIAVIMAS PER GITHUB ACTIONS
Šiame projekte jau yra įdiegta **GitHub Actions** automatizacija. Kai įkelsite šiuos failus į savo asmeninę GitHub saugyklą:

### ⚠️ LABAI SVARBI KLAIDA (Kodėl neveikia Actions):
1. **Paslėpti failai**: Kai atsidarote išarchyvuotą aplanką savo kompiuteryje, **pažymėdami failus nepastebite paslėpto aplanko `.github`**, kadangi Windows ir Mac sistemos jį paslepia. Jei neįkėlėte šio aplanko su visais failais, GitHub robotas negali pradėti darbo!
**Sprendimas:** Įtempkite visą pagrindinį aplanką iškart, arba prieš pažymėdami failus įjunkite rodymą „Rodyti paslėptus elementus (Hidden items)“.

2. **README.md klaida**: Jei sukurdami naują repozitoriją pažymėjote "Add a README file", puslapis jau nebus tuščias. Tokiu atveju vietoj „uploading an existing file“ nuorodos, viršuje dešinėje užeikite ant **Add file > Upload files** ir įtempkite failus ten.

1. Viršutiniame meniu eikite į **Actions** skirtuką.
2. Pasirinkite vykstantį procesą (geltonas taškelis) arba baigtą procesą (žalias ✓) pavadinimu **Build APK**.
3. Puslapio apačioje skyriuje **Artifacts** pamatysite atsisiuntimo nuorodą **TopFilmaiTV-APK**. Paspauskite ją ir jūsų naršyklė iškart parsiųs gatavą **app-debug.apk** failą!

## 🛠️ KAIP SUKOMPILIUOTI SAVO KOMPIUTERYJE (ANDROID STUDIO)
1. Atsidarykite **Android Studio**.
2. Pasirinkite **File > Open** ir nurodykite šią atarchyvuotą direktoriją.
3. Leiskite Android Studio automatiškai sukonfigūruoti Gradle aplinką (jau pridėti visi gradle-wrapper nustatymai).
4. Meniu rinkitės **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK failas bus įrašytas į `app/build/outputs/apk/debug/app-debug.apk`.
