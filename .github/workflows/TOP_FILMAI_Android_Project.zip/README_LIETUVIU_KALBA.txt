=== TOP FILMAI - ANDROID TV LEANBACK PROJEKTAS ===
Sveikiname atsisiuntus paruoštą gamyklinį Android Studio pirminį kodą jūsų Formuler Z12 Ultra priedėliui!

PROJEKTO GALIMYBĖS:
1. Pilnas D-Pad navigacijos perėmimas WebView (viršūnėse švies ryškus geltonas rėmelis, slankiojama pultelio mygtukais).
2. Vaizdo grotuvo atsukimas / prasukimas nuotolinio valdymo klavišais (Kairė, Dešinė, OK).
3. Vaizdo persukimas tiesiai į procentinę dalį pultelio skaičiais (1-9).
4. Saugus mišrių srautų bei tiesioginių IP rodymas be SSL block (evaluateJavascript & usesCleartextTraffic).
5. AUTOMATINIS VERTĖJAS FONE: Programa fone randa svetainėje rodomus EN / DE subtitrus, fone išverčia juos į lietuvių kalbą ir garsiai perskaito per vietinį Android Text-To-Speech (TTS) sintezatorių realiu laiku!
6. GARSO PRITILDYMAS (DUCKING): Kai diktorius įgarsina lietuviškai fone, originalaus filmo garsumą automatiškai nusukame iki 30%, kad girdėtumėte maksimaliai aiškiai ir švariai 81cm ekrano kolonėlėse.
7. PULTELIO AUDIO ARBA MUTE KLAVIŠU: Galite bet kada įjungti arba išjungti šis lietuvišką įgarsinimą tiesiai iš GTV-BT3 pultelio.

-----------------------------------------------------------
METODAS A: NEMOKAMAS AUTOMATINIS KOMPILIAVIMAS INTERNETE (Šimtaprocentis būdas be jokių terminalų)
-----------------------------------------------------------
Jeigu neturite įdiegtos „Android Studio“, nenorite siųstis jokių programų ir norite, kad nemokamas tinkle veikiantis kompiliatorius sukurtų .APK fone už jus:

⚠️ LABAI SVARBI KLAIDA, DĖL KURIOS NEVEIKIA GITHUB ACTIONS AUTOMATAS:
1. Windows ir macOS kompiuteriai pagal nutylėjimą SLEPIA aplankus ir failus, kurie prasideda tašku (pvz. paslėptas aplankas ".github").
Jei išarchyvavote ZIP failą, atsidarėte jį, pasirinkote visus failus ir įtempėte juos į GitHub – jūsų kompiuteris NEĮKELIA ".github" aplanko! Dėl to robotas nepradės darbo!
Sprendimas: Pažymėdami failus įsitikinkite, kad įtempėte patį PAGRINDINĮ išarchyvuotą aplanką (visą geltoną katalogą iškart), arba savo kompiuteryje įjunkite paslėptų elementų rodymą.

2. DĖL "README.md" KLAIDOS SUKURIANT PROJEKTĄ:
Jei kurdami naują saugyklą (Repository) pažymėjote langelį "Add a README file", GitHub sukuria projektą, kuris JAU NĖRA tuščias. Tokiu atveju nematysite mėlyno užrašo "uploading an existing file".
Sprendimas: Jei puslapis nėra tuščias, viršuje dešinėje pusėje raskite pilką mygtuką "Add file" -> pasirinkite "Upload files" ir įtempkite failus ten!

KAIP TAI PADARYTI ŽINGSNIS PO ŽINGSNIO BE KLAIDŲ:
1. Prisijunkite prie savo nemokamos https://github.com paskyros naršyklėje.
2. Paspauskite žalią mygtuką "New" (sukurti naują projektą).
3. Pavadinkite jį bet kaip (pvz., "topfilmaitv"). Įsitikinkite, kad nustatytas kaip PRIVATUS (Private) arba VIEŠAS (Public).
4. SVARBU: NEŽYMĖKITE jokių varnelių ("Add a README file", ".gitignore" ar kt.) ir iškart spauskite žalią mygtuką "Create repository" apačioje.
5. Naujame tuščiame lange pamatysite daug kodo eilučių, bet jūsų tikslas yra rasti mažą mėlyną derinį: "uploading an existing file". Paspauskite ant mėlyno užrašo "uploading an existing file".
6. Įtempkite VISUS išarchyvuoto projekto failus ir katalogus (ypač paslėptą ".github" aplanką bei "app" aplanką) į naršyklės langą. Rekomenduojame tiesiog įtempti pačius failus iškart arba rodyti paslėptus elementus.
7. Kai visi failai (maždaug 15-20 vnt.) bus įkelti, paspauskite žalią mygtuką apačioje "Commit changes" (gali užtrukti kelias sekundes).
8. Viršutiniame GitHub meniu nukeliaukite į skirtuką "Actions" (pamatysite geltoną apskritimą, reiškiantį, kad robotas gavo instrukcijas ir jau pradėjo kompiliuoti!).
9. Už maždaug 1-2 minučių geltonas apskritimas virs žalia varnele (✓). Paspauskite ant jos arba ant įrašo "Build APK".
10. Puslapio apačioje atsidariusiame "Artifacts" skyriuje pamatysite atsisiuntimo nuorodą "TopFilmaiTV-APK". Paspauskite ant jos ir jūsų naršyklė iškart parsiųs gatavą sukompiliuotą „app-debug.apk“ failą tiesiai į jūsų kompiuterį!

-----------------------------------------------------------
METODAS B: STANDARTINIS KOMPILIAVIMAS PER ANDROID STUDIO (Su gamykliniu Gradle rinkiniu)
-----------------------------------------------------------
Mūsų sugeneruotame ZIP faile jau yra pilnas „Gradle Wrapper“ rinkinys (įskaitant .properties ir .jar failus).
1. Atsidarykite įdiegtą nemokamą Android Studio (https://developer.android.com/studio).
2. Pasirinkite "File > Open" ir nurodykite šią atarchyvuotą direktoriją.
3. Android Studio iškart atpažins projektą pagal mūsų suformuotą Gradle Wrapper ir automatiškai sukonfigūruos visą sistemą (trunka 2-3 minutes).
4. Pasirinkite viršutiniame meni: "Build > Build Bundle(s) / APK(s) > Build APK(s)".
5. Gatavą APK gausite kataloge "app/build/outputs/apk/debug/app-debug.apk".

-----------------------------------------------------------
KAIP ĮRAŠYTI Į FORMULER Z12 ULTRA PRIEDĖLĮ:
-----------------------------------------------------------
1. Nukopijuokite gautą "app-debug.apk" failą į USB atmintuką ir įkiškite į Formuler priedėlį, ARBA naudokite nemokamą programėlę "Send Files to TV" (atsisiųskite ją iš Google Play televizoriuje ir išmaniajame telefone).
2. Atidarykite priedėlio failų naršyklę (File Manager / File Browser), pasirinkite perkeltą .apk failą ir atlikite diegimą.
3. Paleiskite TOP FILMAI programėlę ir mėgaukitės!
