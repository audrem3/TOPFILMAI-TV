@echo off
set "CLI_JAR=gradle\wrapper\gradle-wrapper.jar"
if not exist "%CLI_JAR%" (
    if not exist gradle\wrapper mkdir gradle\wrapper
    echo Atsisiunciamas trukstamas Gradle Wrapper irankis...
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest https://raw.githubusercontent.com/gradle/gradle/v8.1.1/gradle/wrapper/gradle-wrapper.jar -OutFile %CLI_JAR%"
)
java -jar "%CLI_JAR%" %*
