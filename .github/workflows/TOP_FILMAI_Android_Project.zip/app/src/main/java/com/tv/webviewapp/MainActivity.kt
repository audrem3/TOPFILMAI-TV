package com.tv.webviewapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import java.util.Locale

class MainActivity : FragmentActivity(), TextToSpeech.OnInitListener {

    private lateinit var webView: WebView
    private val TARGET_URL = "https://213.111.148.194"
    
    // Išmaniojo balsinio vertimo fone (Audio-Description Voiceover) valdymo kintamieji:
    private var tts: TextToSpeech? = null
    private var isTtsEnabled = true // Įjungta pagal nutylėjimą
    private var isTtsInitialized = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Konfigūruojame visišką pilno ekrano režimą (Full Screen / Immersive Mode dėsniams)
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )

        webView = findViewById(R.id.webview)
        
        // Inicializuojame TextToSpeech sintezatorių
        tts = TextToSpeech(this, this)
        
        setupWebView()
        webView.loadUrl(TARGET_URL)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            // Nustatome lietuvių kalbos sintezavimą
            val result = tts?.setLanguage(Locale("lt", "LT"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Jeigu televizoriuje nėra įrašyto vietinio lietuviško balso paketo,
                // rekomenduojame įrenginio nustatymuose aktyvuoti Google Speech Services
                Toast.makeText(this, "Rekomenduojama įrašyti lietuvių k. TTS paketą nustatymuose!", Toast.LENGTH_LONG).show()
            } else {
                isTtsInitialized = true
                tts?.setSpeechRate(1.05f) // Šiek tiek padidiname kalbos tempą sinchroniniam filmų vertimui fone
            }
        } else {
            Toast.makeText(this, "Nepavyko paleisti sistemos balso sintezatoriaus", Toast.LENGTH_SHORT).show()
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun setupWebView() {
        // Įjungiame pilną aparatinę GPU akceleraciją Formuler Z12 Ultra vaizdo atkūrimui 4K / UHD srautams
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        
        val settings = webView.settings
        
        // Svarbiausi nustatymai, kad WebView veiktų kaip pilno našumo TV naršyklė:
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false // Leidžia paleisti filmą/srautą tiesiogiai be naudotojo paspaudimo fone
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW // Labai svarbu leidžiant srautus iš tiesioginių IP adresų bei HTTP šaltinių
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        
        // Optimizuojame atmintį ir spartinančiąją atmintinę (caching) sklandžiam buferiavimui
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        
        // Nustatome Smart TV / Android TV User-Agent, kad svetainė automatiškai prisitaikytų prie TV režimo
        settings.userAgentString = "Mozilla/5.0 (Linux; GoogleTV; Formuler Z12 Ultra; GTV-BT3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 SmartTV/1.0"

        // Prijungiame saugų JavascriptInterface, per kurį WebView tiesiogiai iškvies tikrąjį Android balso sintezatorių fone
        webView.addJavascriptInterface(TVAppJavaScriptInterface(), "AndroidAudioTranslator")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Kai puslapis užsikrauna, suleidžiame D-Pad kontrolerio, subtitrų stebėjimo bei garsumo mažinimo scenarijų (JavaScript)
                injectTVControllerScript()
            }
        }
    }

    // Integruojame klaviatūros / TV Pultelio aparatinių mygtukų perėmimą
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            val keyCode = event.keyCode
            
            // Jei paspaustas grįžimo atgal mygtukas
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                if (webView.canGoBack()) {
                    webView.goBack() // Eiti atgal puslapio istorijoje
                    return true
                }
            }
            
            // Perduodame pultelio paspaudimus tiesiai į WebView JavaScript sluoksnį
            val jsKey = when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> "UP"
                KeyEvent.KEYCODE_DPAD_DOWN -> "DOWN"
                KeyEvent.KEYCODE_DPAD_LEFT -> "LEFT"
                KeyEvent.KEYCODE_DPAD_RIGHT -> "RIGHT"
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> "OK"
                KeyEvent.KEYCODE_0, KeyEvent.KEYCODE_NUMPAD_0 -> "0"
                KeyEvent.KEYCODE_1, KeyEvent.KEYCODE_NUMPAD_1 -> "1"
                KeyEvent.KEYCODE_2, KeyEvent.KEYCODE_NUMPAD_2 -> "2"
                KeyEvent.KEYCODE_3, KeyEvent.KEYCODE_NUMPAD_3 -> "3"
                KeyEvent.KEYCODE_4, KeyEvent.KEYCODE_NUMPAD_4 -> "4"
                KeyEvent.KEYCODE_5, KeyEvent.KEYCODE_NUMPAD_5 -> "5"
                KeyEvent.KEYCODE_6, KeyEvent.KEYCODE_NUMPAD_6 -> "6"
                KeyEvent.KEYCODE_7, KeyEvent.KEYCODE_NUMPAD_7 -> "7"
                KeyEvent.KEYCODE_8, KeyEvent.KEYCODE_NUMPAD_8 -> "8"
                KeyEvent.KEYCODE_9, KeyEvent.KEYCODE_NUMPAD_9 -> "9"
                
                // Formuler Z12 specializuotų klavišų tiesioginis apdorojimas:
                KeyEvent.KEYCODE_INFO -> "INFO"
                KeyEvent.KEYCODE_MENU -> "MENU"
                
                // Mygtukas AUDIO (Z12 klavišas AUDIO / KEYCODE_MEDIA_AUDIO_TRACK) arba MUTE perjungia balsinio vertimo būseną
                KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK, 222 -> "AUDIO"
                KeyEvent.KEYCODE_MUTE, 164 -> "MUTE"
                else -> null
            }
            
            if (jsKey != null) {
                // Jeigu paspaustas AUDIO arba MUTE - tiesiogiai perjungiam būseną native lygyje ir patvirtinam vizualiai
                if (jsKey == "AUDIO" || jsKey == "MUTE") {
                    isTtsEnabled = !isTtsEnabled
                    if (!isTtsEnabled) {
                        tts?.stop() // nutildome sintezatorių akimirksniu
                        // Atstatome filmo garsą
                        webView.evaluateJavascript("const videos = document.querySelectorAll('video'); videos.forEach(v => { v.volume = parseFloat(v.dataset.origVol || 1.0); });", null)
                    }
                    val msg = if (isTtsEnabled) "🔊 Lietuviškas vertimas fone: ĮJUNGTAS" else "🔇 Lietuviškas vertimas fone: IŠJUNGTAS"
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                }

                // Paleidžiame specialiai sukonfigūruotą javascript funkciją puslapyje, kad simuliatorius / svetainė irgi žinotų būseną
                webView.evaluateJavascript("if (window.handleTVRemoteKey) { window.handleTVRemoteKey('$jsKey'); }", null)
                
                // Jeigu pultelis yra vaizdo grotuvo režime, mes norime blokuoti standartinius fokusavimus
                if (jsKey == "LEFT" || jsKey == "RIGHT" || jsKey == "OK") {
                    // Jei svetainėje dabar paleistas video, grąžiname true
                    webView.evaluateJavascript("navigator.mediaSession && navigator.mediaSession.playbackState === 'playing'", { isPlaying -> })
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // Java/Kotlin sąveikos tiltas su HTML5 puslapio elementais
    inner class TVAppJavaScriptInterface {
        
        @JavascriptInterface
        fun speakSubtitle(text: String) {
            if (!isTtsEnabled || !isTtsInitialized) return
            
            runOnUiThread {
                try {
                    // 1. DUCKING: Pritildome originalų filmo garsą 30 % (kad diktoriaus balsas būtų kuo aiškesnis)
                    // Atliekama keičiant HTML5 grotuvo <video> elementų garsumą (volume) iki 30% nuo buvusio garso
                    webView.evaluateJavascript("""
                        (function() {
                            const videos = document.querySelectorAll('video');
                            videos.forEach(v => {
                                if (!v.dataset.origVol) {
                                    // Išsaugome pradinį vartotojo nustatytą garsumą, kad žinotume kur sugrįžti
                                    v.dataset.origVol = v.volume !== undefined ? v.volume : 1.0;
                                }
                                // Sumažinamegarsą iki 30% (sumažėjimas 70% arba nustatoma į sklandų 0.3)
                                v.volume = 0.3; 
                            });
                        })();
                    """.trimIndent(), null)

                    // 2. TTS Voiceover paleidimas
                    val params = Bundle()
                    params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f) // Diktoriaus garsas maksimalus ir švarus

                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}

                        override fun onDone(utteranceId: String?) {
                            runOnUiThread {
                                // 3. RENTORING: Kai diktorius baigia kalbėti, iškart atstatome originalų filmo garsą atgal fone
                                webView.evaluateJavascript("""
                                    (function() {
                                        const videos = document.querySelectorAll('video');
                                        videos.forEach(v => {
                                            if (v.dataset.origVol) {
                                                v.volume = parseFloat(v.dataset.origVol);
                                            }
                                        });
                                    })();
                                """.trimIndent(), null)
                            }
                        }

                        override fun onError(utteranceId: String?) {
                            runOnUiThread {
                                // Sutrikus vertimui, taip pat atstatome garsą, kad filmas neliktų pritildytas
                                webView.evaluateJavascript("const videos = document.querySelectorAll('video'); videos.forEach(v => { if (v.dataset.origVol) v.volume = parseFloat(v.dataset.origVol); });", null)
                            }
                        }
                    })

                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "SUBTITLE_TRANS")
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        @JavascriptInterface
        fun getTtsStatus(): Boolean {
            return isTtsEnabled
        }
    }

    override fun onDestroy() {
        if (tts != null) {
            tts?.stop()
            tts?.shutdown()
        }
        super.onDestroy()
    }

    private fun injectTVControllerScript() {
        val jsScript = """
            (function() {
                if (window.hasTVRemoteInitialized) return;
                window.hasTVRemoteInitialized = true;

                console.log("TV remote controller script sėkmingai suleistas į svetainę.");

                // Sukuriame globalų stilių, kad fokusas ant elementų būtų ryškus ir matomas iš tolo
                const style = document.createElement('style');
                style.innerHTML = '
                    /* Ryškus geltonas/auksinis rėmelis sufokusuotam elementui */
                    :focus, .tv-focused {
                        outline: 5px solid #ffcc00 !important;
                        outline-offset: 4px !important;
                        box-shadow: 0 0 20px rgba(255, 204, 0, 0.8) !important;
                        transform: scale(1.05) !important;
                        transition: transform 0.15s ease, outline 0.1s ease !important;
                        z-index: 99999 !important;
                    }
                ';
                document.head.appendChild(style);

                // Automatiškai surandame visus paspaudžiamus elementus svetainėje
                function getInteractiveElements() {
                    return Array.from(document.querySelectorAll('a, button, [role="button"], input, select, textarea, .movie-card, .film-tile, [tabindex="0"]'));
                }

                let currentFocusIndex = 0;

                // Nuotolinio pultelio apdorojimo funkcija iškviečiama iš Android WebView
                window.handleTVRemoteKey = function(key) {
                    console.log("Gautas pultelio mygtukas iš Android TV: " + key);
                    
                    if (key === "AUDIO" || key === "MUTE") {
                        // Jei gautas signalas iš fizinio pulto, pasakome apie tai vartotojui
                        const cur = window.AndroidAudioTranslator ? window.AndroidAudioTranslator.getTtsStatus() : true;
                        showTemporaryVideoToast(cur ? "🔊 Vertimas fone: IJUNGTAS" : "🔇 Vertimas fone: ISJUNGTAS");
                        return;
                    }

                    // Tikriname, ar svetainėje dabar yra aktyviai grojamas vaizdo įrašas
                    const videoElement = document.querySelector('video');

                    if (videoElement) {
                        // Jei grojamas filmas, aktyvuojame SPECIALŲ grotuvo valdymą
                        if (key === "LEFT") {
                            // Persukti 10 sekundžių atgal
                            videoElement.currentTime = Math.max(0, videoElement.currentTime - 10);
                            showTemporaryVideoToast("-10s");
                            return;
                        } else if (key === "RIGHT") {
                            // Persukti 10 sekundžių pirmyn
                            videoElement.currentTime = Math.min(videoElement.duration || 100000, videoElement.currentTime + 10);
                            showTemporaryVideoToast("+10s");
                            return;
                        } else if (key === "OK") {
                            // Sustabdyti arba paleisti
                            if (videoElement.paused) {
                                videoElement.play();
                                showTemporaryVideoToast("Paleisti (Play)");
                            } else {
                                videoElement.pause();
                                showTemporaryVideoToast("Sustabdyti (Pause)");
                            }
                            return;
                        } else if (/[0-9]/.test(key)) {
                            // Skaičių klavišai persuka į procentinę dalį
                            const percent = parseInt(key) * 10;
                            if (videoElement.duration) {
                                videoElement.currentTime = (videoElement.duration * percent) / 100;
                                showTemporaryVideoToast("Persukta " + percent + "%");
                            }
                            return;
                        }
                    }

                    // Jei video negroja, vyksta standartinis D-Pad elementų fokusavimas svetainėje
                    const elements = getInteractiveElements();
                    if (elements.length === 0) return;

                    // Išvalome seną klasę
                    elements.forEach(el => el.classList.remove('tv-focused'));

                    if (key === "DOWN") {
                        currentFocusIndex = (currentFocusIndex + 4) % elements.length;
                    } else if (key === "UP") {
                        currentFocusIndex = (currentFocusIndex - 4 + elements.length) % elements.length;
                    } else if (key === "RIGHT") {
                        currentFocusIndex = (currentFocusIndex + 1) % elements.length;
                    } else if (key === "LEFT") {
                        currentFocusIndex = (currentFocusIndex - 1 + elements.length) % elements.length;
                    } else if (key === "OK") {
                        const activeEl = elements[currentFocusIndex];
                        if (activeEl) {
                            activeEl.click();
                            if (activeEl.focus) activeEl.focus();
                        }
                        return;
                    } else if (key === "INFO") {
                        showTemporaryVideoToast("Formuler Z12 INFO: Signalo kokybė 100% | UHD stream");
                        return;
                    } else if (key === "MENU") {
                        showTemporaryVideoToast("Formuler Z12 MENU: Atidaromas pagrindinis puslapis");
                        window.scrollTo({top: 0, behavior: 'smooth'});
                        return;
                    }

                    // Uždedame naują fokusą
                    const newFocused = elements[currentFocusIndex];
                    if (newFocused) {
                        newFocused.focus();
                        newFocused.classList.add('tv-focused');
                        newFocused.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                };

                // --- INTEGRALUS AUTOMATINIS SUBTITRŲ VERTĖJAS FONE ---
                // Stebime HTML puslapio elementus, kuriuose pasirodo subtitrai (MutationObserver)
                let lastObservedSubtitleText = "";
                const subtitleObserverObj = new MutationObserver(function(mutations) {
                    mutations.forEach(function(mutation) {
                        if (mutation.type === "childList" || mutation.type === "characterData") {
                            checkActiveSubtitlesOnPage();
                        }
                    });
                });

                // Pradedame viso puslapio stebėjimą subtitrams surasti
                subtitleObserverObj.observe(document.body, {
                    childList: true,
                    subtree: true,
                    characterData: true
                });

                function checkActiveSubtitlesOnPage() {
                    // Tipinės subtitrų HTML klasės populiariuose grotuvuose (Video.js, Plyr, JWPlayer, custom):
                    const subtitleSelectors = [
                        '.vjs-text-track-display', '.video-js .vjs-subtitles', '.subtitles', 
                        '.jw-text-track-container', '.caption-text', '.video-captions',
                        '.plyr__captions', '.subtitle-line', '.ytp-caption-segment'
                    ];

                    let subTextFound = "";
                    for (let selector of subtitleSelectors) {
                        const el = document.querySelector(selector);
                        if (el && el.innerText && el.innerText.trim().length > 0) {
                            subTextFound = el.innerText.trim();
                            break;
                        }
                    }

                    // Jei nerandame pagal žinomas klases, stebime elementus turinčius specifinius stilius:
                    if (!subTextFound) {
                        const allDivs = document.querySelectorAll('div, span, p');
                        for (let element of allDivs) {
                            // Subtitrai dažniausiai būna pozicionuojami apačioje ir turi permatomą tamsų foną
                            const style = window.getComputedStyle(element);
                            if ((style.position === 'absolute' || style.position === 'fixed') && 
                                parseInt(style.bottom) < 150 && 
                                (style.backgroundColor.includes('rgba(0') || style.background === 'black') &&
                                element.innerText && element.innerText.trim().length > 0) {
                                subTextFound = element.innerText.trim();
                                break;
                            }
                        }
                    }

                    // Jei radome naują subtitrą ir jis skiriasi nuo paskutinio:
                    if (subTextFound && subTextFound !== lastObservedSubtitleText) {
                        lastObservedSubtitleText = subTextFound;
                        translateAndSpeak(subTextFound);
                    }
                }

                // Sukuriame greitą ir konfidencialų tiesioginį subtitrą išvertimą fone
                function translateAndSpeak(englishGermanText) {
                    console.log("Aptikti išoriniai subtitrai: " + englishGermanText);
                    
                    // Supaprastintas išorinio vertėjo kvietimas (naudojant Google translate viešą API srautą)
                    const translateTargetUrl = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=lt&dt=t&q=" + encodeURIComponent(englishGermanText);
                    
                    fetch(translateTargetUrl)
                        .then(response => response.json())
                        .then(data => {
                            if (data && data[0] && data[0][0] && data[0][0][0]) {
                                const lithuanianText = data[0][0][0];
                                console.log("Išversta į lietuvių kalbą: " + lithuanianText);
                                
                                // Atsiunčiame išverstą lietuvišką tekstą tiesiai į Android native balso sintezatorių
                                if (window.AndroidAudioTranslator && window.AndroidAudioTranslator.speakSubtitle) {
                                    window.AndroidAudioTranslator.speakSubtitle(lithuanianText);
                                }
                            }
                        })
                        .catch(err => {
                            console.error("Vertimo paslaugos klaida: ", err);
                            // Nesėkmės atveju kaip atsarginį variantą iškart siunčiame originalą arba pranešame sistemos žurnale
                        });
                }

                // Sukuriame vaizdinį „Toast“ pranešimą ant video grotuvo ekrano
                function showTemporaryVideoToast(text) {
                    let toast = document.getElementById('tv-video-toast');
                    if (!toast) {
                        toast = document.createElement('div');
                        toast.id = 'tv-video-toast';
                        toast.style.position = 'fixed';
                        toast.style.bottom = '15%';
                        toast.style.left = '50%';
                        toast.style.transform = 'translateX(-50%)';
                        toast.style.backgroundColor = 'rgba(0, 0, 0, 0.85)';
                        toast.style.color = '#ffcc00';
                        toast.style.padding = '12px 28px';
                        toast.style.borderRadius = '30px';
                        toast.style.fontFamily = 'sans-serif';
                        toast.style.fontSize = '20px';
                        toast.style.fontWeight = 'bold';
                        toast.style.border = '2px solid #ffcc00';
                        toast.style.zIndex = '100000';
                        toast.style.pointerEvents = 'none';
                        toast.style.transition = 'opacity 0.2s';
                        document.body.appendChild(toast);
                    }
                    toast.innerText = text;
                    toast.style.opacity = '1';
                    
                    if (window.toastTimeout) clearTimeout(window.toastTimeout);
                    window.toastTimeout = setTimeout(() => {
                        toast.style.opacity = '0';
                    }, 1500);
                }

                // Pradinė pagalbinė funkcija: automatiškai sufokusuoti pirmąjį elementą atidarius svetainę
                setTimeout(() => {
                    const elements = getInteractiveElements();
                    if (elements.length > 0) {
                        elements[0].focus();
                        elements[0].classList.add('tv-focused');
                    }
                }, 1000);
            })();
        """.trimIndent()
        
        // Vykdome JS suleidimą į puslapį
        webView.evaluateJavascript(jsScript, null)
    }
}
