# ==========================================================
# TOP FILMAI - PROGRAMOS KOMPILIAVIMO AUTOMATAS CLOUD SHELL 🚀
# ==========================================================

echo "🎬 KURIAMAS PROJEKTAS IR PARUOŠIAMA DARBO SRYTIS..."
rm -rf TopFilmaiTV && mkdir -p TopFilmaiTV/app/src/main/java/com/tv/webviewapp
mkdir -p TopFilmaiTV/app/src/main/res/layout
mkdir -p TopFilmaiTV/app/src/main/res/values
cd TopFilmaiTV

echo "✍️ Įrašomas failas: app/src/main/java/com/tv/webviewapp/MainActivity.kt"
cat << 'EOF' > app/src/main/java/com/tv/webviewapp/MainActivity.kt
package com.tv.webviewapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.JavascriptInterface
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.fragment.app.FragmentActivity
import java.util.Locale

class MainActivity : FragmentActivity(), TextToSpeech.OnInitListener {

    private lateinit var webView: WebView
    private val TARGET_URL = "https://213.111.148.194"
    
    // Išmaniojo balsinio vertimo fone (Audio-Description Voiceover) valdymo kintamieji:
    private var tts: TextToSpeech? = null
    private var isTtsEnabled = true // Įjungta pagal nutylėjimą
    private var isTtsInitialized = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Konfigūruojame visišką pilno ekrano režimą (Full Screen / Immersive Mode dėsniams)
        window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )

        webView = findViewById(R.id.webview)
        
        // Inicializuojame TextToSpeech sintezatorių
        tts = TextToSpeech(this, this)
        
        setupWebView()
        webView.loadUrl(TARGET_URL)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            // Nustatome lietuvių kalbos sintezavimą
            val result = tts?.setLanguage(Locale("lt", "LT"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Jeigu televizoriuje nėra įrašyto vietinio lietuviško balso paketo,
                // rekomenduojame įrenginio nustatymuose aktyvuoti Google Speech Services
                Toast.makeText(this, "Rekomenduojama įrašyti lietuvių k. TTS paketą nustatymuose!", Toast.LENGTH_LONG).show()
            } else {
                isTtsInitialized = true
                tts?.setSpeechRate(1.05f) // Šiek tiek padidiname kalbos tempą sinchroniniam filmų vertimui fone
            }
        } else {
            Toast.makeText(this, "Nepavyko paleisti sistemos balso sintezatoriaus", Toast.LENGTH_SHORT).show()
        }
    }

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    private fun setupWebView() {
        // Įjungiame pilną aparatinę GPU akceleraciją Formuler Z12 Ultra vaizdo atkūrimui 4K / UHD srautams
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        
        val settings = webView.settings
        
        // Svarbiausi nustatymai, kad WebView veiktų kaip pilno našumo TV naršyklė:
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false // Leidžia paleisti filmą/srautą tiesiogiai be naudotojo paspaudimo fone
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW // Labai svarbu leidžiant srautus iš tiesioginių IP adresų bei HTTP šaltinių
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        
        // Optimizuojame atmintį ir spartinančiąją atmintinę (caching) sklandžiam buferiavimui
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        
        // Nustatome Smart TV / Android TV User-Agent, kad svetainė automatiškai prisitaikytų prie TV režimo
        settings.userAgentString = "Mozilla/5.0 (Linux; GoogleTV; Formuler Z12 Ultra; GTV-BT3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36 SmartTV/1.0"

        // Prijungiame saugų JavascriptInterface, per kurį WebView tiesiogiai iškvies tikrąjį Android balso sintezatorių fone
        webView.addJavascriptInterface(TVAppJavaScriptInterface(), "AndroidAudioTranslator")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Kai puslapis užsikrauna, suleidžiame D-Pad kontrolerio, subtitrų stebėjimo bei garsumo mažinimo scenarijų (JavaScript)
                injectTVControllerScript()
            }
        }
    }

    // Integruojame klaviatūros / TV Pultelio aparatinių mygtukų perėmimą
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            val keyCode = event.keyCode
            
            // Jei paspaustas grįžimo atgal mygtukas
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                if (webView.canGoBack()) {
                    webView.goBack() // Eiti atgal puslapio istorijoje
                    return true
                }
            }
            
            // Perduodame pultelio paspaudimus tiesiai į WebView JavaScript sluoksnį
            val jsKey = when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP -> "UP"
                KeyEvent.KEYCODE_DPAD_DOWN -> "DOWN"
                KeyEvent.KEYCODE_DPAD_LEFT -> "LEFT"
                KeyEvent.KEYCODE_DPAD_RIGHT -> "RIGHT"
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> "OK"
                KeyEvent.KEYCODE_0, KeyEvent.KEYCODE_NUMPAD_0 -> "0"
                KeyEvent.KEYCODE_1, KeyEvent.KEYCODE_NUMPAD_1 -> "1"
                KeyEvent.KEYCODE_2, KeyEvent.KEYCODE_NUMPAD_2 -> "2"
                KeyEvent.KEYCODE_3, KeyEvent.KEYCODE_NUMPAD_3 -> "3"
                KeyEvent.KEYCODE_4, KeyEvent.KEYCODE_NUMPAD_4 -> "4"
                KeyEvent.KEYCODE_5, KeyEvent.KEYCODE_NUMPAD_5 -> "5"
                KeyEvent.KEYCODE_6, KeyEvent.KEYCODE_NUMPAD_6 -> "6"
                KeyEvent.KEYCODE_7, KeyEvent.KEYCODE_NUMPAD_7 -> "7"
                KeyEvent.KEYCODE_8, KeyEvent.KEYCODE_NUMPAD_8 -> "8"
                KeyEvent.KEYCODE_9, KeyEvent.KEYCODE_NUMPAD_9 -> "9"
                
                // Formuler Z12 specializuotų klavišų tiesioginis apdorojimas:
                KeyEvent.KEYCODE_INFO -> "INFO"
                KeyEvent.KEYCODE_MENU -> "MENU"
                
                // Mygtukas AUDIO (Z12 klavišas AUDIO / KEYCODE_MEDIA_AUDIO_TRACK) arba MUTE perjungia balsinio vertimo būseną
                KeyEvent.KEYCODE_MEDIA_AUDIO_TRACK, 222 -> "AUDIO"
                KeyEvent.KEYCODE_MUTE, 164 -> "MUTE"
                else -> null
            }
            
            if (jsKey != null) {
                // Jeigu paspaustas AUDIO arba MUTE - tiesiogiai perjungiam būseną native lygyje ir patvirtinam vizualiai
                if (jsKey == "AUDIO" || jsKey == "MUTE") {
                    isTtsEnabled = !isTtsEnabled
                    if (!isTtsEnabled) {
                        tts?.stop() // nutildome sintezatorių akimirksniu
                        // Atstatome filmo garsą
                        webView.evaluateJavascript("const videos = document.querySelectorAll('video'); videos.forEach(v => { v.volume = parseFloat(v.dataset.origVol || 1.0); });", null)
                    }
                    val msg = if (isTtsEnabled) "🔊 Lietuviškas vertimas fone: ĮJUNGTAS" else "🔇 Lietuviškas vertimas fone: IŠJUNGTAS"
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                }

                // Paleidžiame specialiai sukonfigūruotą javascript funkciją puslapyje, kad simuliatorius / svetainė irgi žinotų būseną
                webView.evaluateJavascript("if (window.handleTVRemoteKey) { window.handleTVRemoteKey('$jsKey'); }", null)
                
                // Jeigu pultelis yra vaizdo grotuvo režime, mes norime blokuoti standartinius fokusavimus
                if (jsKey == "LEFT" || jsKey == "RIGHT" || jsKey == "OK") {
                    // Jei svetainėje dabar paleistas video, grąžiname true
                    webView.evaluateJavascript("navigator.mediaSession && navigator.mediaSession.playbackState === 'playing'", { isPlaying -> })
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // Java/Kotlin sąveikos tiltas su HTML5 puslapio elementais
    inner class TVAppJavaScriptInterface {
        
        @JavascriptInterface
        fun speakSubtitle(text: String) {
            if (!isTtsEnabled || !isTtsInitialized) return
            
            runOnUiThread {
                try {
                    // 1. DUCKING: Pritildome originalų filmo garsą 30 % (kad diktoriaus balsas būtų kuo aiškesnis)
                    // Atliekama keičiant HTML5 grotuvo <video> elementų garsumą (volume) iki 30% nuo buvusio garso
                    webView.evaluateJavascript("""
                        (function() {
                            const videos = document.querySelectorAll('video');
                            videos.forEach(v => {
                                if (!v.dataset.origVol) {
                                    // Išsaugome pradinį vartotojo nustatytą garsumą, kad žinotume kur sugrįžti
                                    v.dataset.origVol = v.volume !== undefined ? v.volume : 1.0;
                                }
                                // Sumažinamegarsą iki 30% (sumažėjimas 70% arba nustatoma į sklandų 0.3)
                                v.volume = 0.3; 
                            });
                        })();
                    """.trimIndent(), null)

                    // 2. TTS Voiceover paleidimas
                    val params = Bundle()
                    params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f) // Diktoriaus garsas maksimalus ir švarus

                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}

                        override fun onDone(utteranceId: String?) {
                            runOnUiThread {
                                // 3. RENTORING: Kai diktorius baigia kalbėti, iškart atstatome originalų filmo garsą atgal fone
                                webView.evaluateJavascript("""
                                    (function() {
                                        const videos = document.querySelectorAll('video');
                                        videos.forEach(v => {
                                            if (v.dataset.origVol) {
                                                v.volume = parseFloat(v.dataset.origVol);
                                            }
                                        });
                                    })();
                                """.trimIndent(), null)
                            }
                        }

                        override fun onError(utteranceId: String?) {
                            runOnUiThread {
                                // Sutrikus vertimui, taip pat atstatome garsą, kad filmas neliktų pritildytas
                                webView.evaluateJavascript("const videos = document.querySelectorAll('video'); videos.forEach(v => { if (v.dataset.origVol) v.volume = parseFloat(v.dataset.origVol); });", null)
                            }
                        }
                    })

                    tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "SUBTITLE_TRANS")
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        @JavascriptInterface
        fun getTtsStatus(): Boolean {
            return isTtsEnabled
        }
    }

    override fun onDestroy() {
        if (tts != null) {
            tts?.stop()
            tts?.shutdown()
        }
        super.onDestroy()
    }

    private fun injectTVControllerScript() {
        val jsScript = """
            (function() {
                if (window.hasTVRemoteInitialized) return;
                window.hasTVRemoteInitialized = true;

                console.log("TV remote controller script sėkmingai suleistas į svetainę.");

                // Sukuriame globalų stilių, kad fokusas ant elementų būtų ryškus ir matomas iš tolo
                const style = document.createElement('style');
                style.innerHTML = '
                    /* Ryškus geltonas/auksinis rėmelis sufokusuotam elementui */
                    :focus, .tv-focused {
                        outline: 5px solid #ffcc00 !important;
                        outline-offset: 4px !important;
                        box-shadow: 0 0 20px rgba(255, 204, 0, 0.8) !important;
                        transform: scale(1.05) !important;
                        transition: transform 0.15s ease, outline 0.1s ease !important;
                        z-index: 99999 !important;
                    }
                ';
                document.head.appendChild(style);

                // Automatiškai surandame visus paspaudžiamus elementus svetainėje
                function getInteractiveElements() {
                    return Array.from(document.querySelectorAll('a, button, [role="button"], input, select, textarea, .movie-card, .film-tile, [tabindex="0"]'));
                }

                let currentFocusIndex = 0;

                // Nuotolinio pultelio apdorojimo funkcija iškviečiama iš Android WebView
                window.handleTVRemoteKey = function(key) {
                    console.log("Gautas pultelio mygtukas iš Android TV: " + key);
                    
                    if (key === "AUDIO" || key === "MUTE") {
                        // Jei gautas signalas iš fizinio pulto, pasakome apie tai vartotojui
                        const cur = window.AndroidAudioTranslator ? window.AndroidAudioTranslator.getTtsStatus() : true;
                        showTemporaryVideoToast(cur ? "🔊 Vertimas fone: IJUNGTAS" : "🔇 Vertimas fone: ISJUNGTAS");
                        return;
                    }

                    // Tikriname, ar svetainėje dabar yra aktyviai grojamas vaizdo įrašas
                    const videoElement = document.querySelector('video');

                    if (videoElement) {
                        // Jei grojamas filmas, aktyvuojame SPECIALŲ grotuvo valdymą
                        if (key === "LEFT") {
                            // Persukti 10 sekundžių atgal
                            videoElement.currentTime = Math.max(0, videoElement.currentTime - 10);
                            showTemporaryVideoToast("-10s");
                            return;
                        } else if (key === "RIGHT") {
                            // Persukti 10 sekundžių pirmyn
                            videoElement.currentTime = Math.min(videoElement.duration || 100000, videoElement.currentTime + 10);
                            showTemporaryVideoToast("+10s");
                            return;
                        } else if (key === "OK") {
                            // Sustabdyti arba paleisti
                            if (videoElement.paused) {
                                videoElement.play();
                                showTemporaryVideoToast("Paleisti (Play)");
                            } else {
                                videoElement.pause();
                                showTemporaryVideoToast("Sustabdyti (Pause)");
                            }
                            return;
                        } else if (/[0-9]/.test(key)) {
                            // Skaičių klavišai persuka į procentinę dalį
                            const percent = parseInt(key) * 10;
                            if (videoElement.duration) {
                                videoElement.currentTime = (videoElement.duration * percent) / 100;
                                showTemporaryVideoToast("Persukta " + percent + "%");
                            }
                            return;
                        }
                    }

                    // Jei video negroja, vyksta standartinis D-Pad elementų fokusavimas svetainėje
                    const elements = getInteractiveElements();
                    if (elements.length === 0) return;

                    // Išvalome seną klasę
                    elements.forEach(el => el.classList.remove('tv-focused'));

                    if (key === "DOWN") {
                        currentFocusIndex = (currentFocusIndex + 4) % elements.length;
                    } else if (key === "UP") {
                        currentFocusIndex = (currentFocusIndex - 4 + elements.length) % elements.length;
                    } else if (key === "RIGHT") {
                        currentFocusIndex = (currentFocusIndex + 1) % elements.length;
                    } else if (key === "LEFT") {
                        currentFocusIndex = (currentFocusIndex - 1 + elements.length) % elements.length;
                    } else if (key === "OK") {
                        const activeEl = elements[currentFocusIndex];
                        if (activeEl) {
                            activeEl.click();
                            if (activeEl.focus) activeEl.focus();
                        }
                        return;
                    } else if (key === "INFO") {
                        showTemporaryVideoToast("Formuler Z12 INFO: Signalo kokybė 100% | UHD stream");
                        return;
                    } else if (key === "MENU") {
                        showTemporaryVideoToast("Formuler Z12 MENU: Atidaromas pagrindinis puslapis");
                        window.scrollTo({top: 0, behavior: 'smooth'});
                        return;
                    }

                    // Uždedame naują fokusą
                    const newFocused = elements[currentFocusIndex];
                    if (newFocused) {
                        newFocused.focus();
                        newFocused.classList.add('tv-focused');
                        newFocused.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                };

                // --- INTEGRALUS AUTOMATINIS SUBTITRŲ VERTĖJAS FONE ---
                // Stebime HTML puslapio elementus, kuriuose pasirodo subtitrai (MutationObserver)
                let lastObservedSubtitleText = "";
                const subtitleObserverObj = new MutationObserver(function(mutations) {
                    mutations.forEach(function(mutation) {
                        if (mutation.type === "childList" || mutation.type === "characterData") {
                            checkActiveSubtitlesOnPage();
                        }
                    });
                });

                // Pradedame viso puslapio stebėjimą subtitrams surasti
                subtitleObserverObj.observe(document.body, {
                    childList: true,
                    subtree: true,
                    characterData: true
                });

                function checkActiveSubtitlesOnPage() {
                    // Tipinės subtitrų HTML klasės populiariuose grotuvuose (Video.js, Plyr, JWPlayer, custom):
                    const subtitleSelectors = [
                        '.vjs-text-track-display', '.video-js .vjs-subtitles', '.subtitles', 
                        '.jw-text-track-container', '.caption-text', '.video-captions',
                        '.plyr__captions', '.subtitle-line', '.ytp-caption-segment'
                    ];

                    let subTextFound = "";
                    for (let selector of subtitleSelectors) {
                        const el = document.querySelector(selector);
                        if (el && el.innerText && el.innerText.trim().length > 0) {
                            subTextFound = el.innerText.trim();
                            break;
                        }
                    }

                    // Jei nerandame pagal žinomas klases, stebime elementus turinčius specifinius stilius:
                    if (!subTextFound) {
                        const allDivs = document.querySelectorAll('div, span, p');
                        for (let element of allDivs) {
                            // Subtitrai dažniausiai būna pozicionuojami apačioje ir turi permatomą tamsų foną
                            const style = window.getComputedStyle(element);
                            if ((style.position === 'absolute' || style.position === 'fixed') && 
                                parseInt(style.bottom) < 150 && 
                                (style.backgroundColor.includes('rgba(0') || style.background === 'black') &&
                                element.innerText && element.innerText.trim().length > 0) {
                                subTextFound = element.innerText.trim();
                                break;
                            }
                        }
                    }

                    // Jei radome naują subtitrą ir jis skiriasi nuo paskutinio:
                    if (subTextFound && subTextFound !== lastObservedSubtitleText) {
                        lastObservedSubtitleText = subTextFound;
                        translateAndSpeak(subTextFound);
                    }
                }

                // Sukuriame greitą ir konfidencialų tiesioginį subtitrą išvertimą fone
                function translateAndSpeak(englishGermanText) {
                    console.log("Aptikti išoriniai subtitrai: " + englishGermanText);
                    
                    // Supaprastintas išorinio vertėjo kvietimas (naudojant Google translate viešą API srautą)
                    const translateTargetUrl = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=lt&dt=t&q=" + encodeURIComponent(englishGermanText);
                    
                    fetch(translateTargetUrl)
                        .then(response => response.json())
                        .then(data => {
                            if (data && data[0] && data[0][0] && data[0][0][0]) {
                                const lithuanianText = data[0][0][0];
                                console.log("Išversta į lietuvių kalbą: " + lithuanianText);
                                
                                // Atsiunčiame išverstą lietuvišką tekstą tiesiai į Android native balso sintezatorių
                                if (window.AndroidAudioTranslator && window.AndroidAudioTranslator.speakSubtitle) {
                                    window.AndroidAudioTranslator.speakSubtitle(lithuanianText);
                                }
                            }
                        })
                        .catch(err => {
                            console.error("Vertimo paslaugos klaida: ", err);
                            // Nesėkmės atveju kaip atsarginį variantą iškart siunčiame originalą arba pranešame sistemos žurnale
                        });
                }

                // Sukuriame vaizdinį „Toast“ pranešimą ant video grotuvo ekrano
                function showTemporaryVideoToast(text) {
                    let toast = document.getElementById('tv-video-toast');
                    if (!toast) {
                        toast = document.createElement('div');
                        toast.id = 'tv-video-toast';
                        toast.style.position = 'fixed';
                        toast.style.bottom = '15%';
                        toast.style.left = '50%';
                        toast.style.transform = 'translateX(-50%)';
                        toast.style.backgroundColor = 'rgba(0, 0, 0, 0.85)';
                        toast.style.color = '#ffcc00';
                        toast.style.padding = '12px 28px';
                        toast.style.borderRadius = '30px';
                        toast.style.fontFamily = 'sans-serif';
                        toast.style.fontSize = '20px';
                        toast.style.fontWeight = 'bold';
                        toast.style.border = '2px solid #ffcc00';
                        toast.style.zIndex = '100000';
                        toast.style.pointerEvents = 'none';
                        toast.style.transition = 'opacity 0.2s';
                        document.body.appendChild(toast);
                    }
                    toast.innerText = text;
                    toast.style.opacity = '1';
                    
                    if (window.toastTimeout) clearTimeout(window.toastTimeout);
                    window.toastTimeout = setTimeout(() => {
                        toast.style.opacity = '0';
                    }, 1500);
                }

                // Pradinė pagalbinė funkcija: automatiškai sufokusuoti pirmąjį elementą atidarius svetainę
                setTimeout(() => {
                    const elements = getInteractiveElements();
                    if (elements.length > 0) {
                        elements[0].focus();
                        elements[0].classList.add('tv-focused');
                    }
                }, 1000);
            })();
        """.trimIndent()
        
        // Vykdome JS suleidimą į puslapį
        webView.evaluateJavascript(jsScript, null)
    }
}

EOF

echo "✍️ Įrašomas failas: app/src/main/AndroidManifest.xml"
cat << 'EOF' > app/src/main/AndroidManifest.xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.tv.webviewapp">

    <!-- Reikalingi leidimai internetui pasiekti -->
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <!-- Android TV specifikacija (Pultelio ir televizoriaus ekrano nustatymai) -->
    <uses-feature
        android:name="android.software.leanback"
        android:required="true" />
    <uses-feature
        android:name="android.hardware.touchscreen"
        android:required="false" />

    <application
        android:allowBackup="true"
        android:banner="@drawable/app_banner"
        android:icon="@drawable/ic_launcher"
        android:label="TOP FILMAI"
        android:logo="@drawable/app_banner"
        android:supportsRtl="true"
        android:theme="@style/Theme.TVWebView"
        android:usesCleartextTraffic="true"> <!-- Leidžia krauti ne HTTPS adresus ir tiesioginius IP -->

        <activity
            android:name=".MainActivity"
            android:banner="@drawable/app_banner"
            android:exported="true"
            android:icon="@drawable/ic_launcher"
            android:label="TOP FILMAI"
            android:logo="@drawable/app_banner"
            android:screenOrientation="landscape"> <!-- Svarbu: TV programos visada turi būti gulsčiame režime -->
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />

                <!-- Leanback Launcher kategorija užtikrina, kad aplikacija matysis Android TV pagrindiniame meniu -->
                <category android:name="android.intent.category.LEANBACK_LAUNCHER" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>

EOF

echo "✍️ Įrašomas failas: app/src/main/res/layout/activity_main.xml"
cat << 'EOF' > app/src/main/res/layout/activity_main.xml
<?xml version="1.0" encoding="utf-8"?>
<FrameLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#000000">

    <!-- Pilnaekranis WebView be jokių navigacijos elementų ir rėmelių -->
    <WebView
        android:id="@+id/webview"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:focusable="true"
        android:focusableInTouchMode="true" />

</FrameLayout>

EOF

echo "✍️ Įrašomas failas: app/src/main/res/values/themes.xml"
cat << 'EOF' > app/src/main/res/values/themes.xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <!-- Leanback dizaino tema, pritaikyta tikram Android TV pultelio fokusavimo valdymui -->
    <style name="Theme.TVWebView" parent="android:Theme.NoTitleBar.Fullscreen">
        <item name="android:windowNoTitle">true</item>
        <item name="android:windowFullscreen">true</item>
        <item name="android:windowContentOverlay">@null</item>
        <item name="android:background">#000000</item>
    </style>
</resources>

EOF

echo "✍️ Įrašomas failas: app/build.gradle"
cat << 'EOF' > app/build.gradle
plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
}

android {
    namespace 'com.tv.webviewapp'
    compileSdk 34

    defaultConfig {
        applicationId "com.tv.webviewapp"
        minSdk 21 // Palaiko net senesnius televizorius nuo Android 5.0
        targetSdk 34
        versionCode 1
        versionName "1.0"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = '1.8'
    }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.leanback:leanback:1.0.0' // Svarbi Android TV pultelio optimizacija
}

EOF

echo "✍️ Įrašomas failas: app/src/main/res/drawable/ic_launcher.xml"
cat << 'EOF' > app/src/main/res/drawable/ic_launcher.xml
<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <!-- Juodas fonas -->
    <path
        android:fillColor="#FF0C1020"
        android:pathData="M0,0h108v108h-108z"/>
    <!-- Mėlyna spindinti aureolė -->
    <path
        android:fillColor="#FF2563EB"
        android:pathData="M54,12C30.8,12,12,30.8,12,54s18.8,42,42,42s42-18.8,42-42S77.2,12,54,12z M54,84C37.4,84,24,70.6,24,54s13.4-30,30-30s30,13.4,30,30S70.6,84,54,84z"/>
    <!-- Paleidimo trikampis (Play mygtukas gintarinis/auksinis) -->
    <path
        android:fillColor="#FFFFCC00"
        android:pathData="M44,38l24,16l-24,16z"/>
</vector>

EOF

echo "✍️ Įrašomas failas: app/src/main/res/drawable/app_banner.xml"
cat << 'EOF' > app/src/main/res/drawable/app_banner.xml
<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="320dp"
    android:height="180dp"
    android:viewportWidth="320"
    android:viewportHeight="180">
    <!-- Elegantiškas tamsus fonas -->
    <path
        android:fillColor="#FF0C1020"
        android:pathData="M0,0h320v180h-320z"/>
    <!-- Dekoratyvinis šoninis akcentas -->
    <path
        android:fillColor="#FF1E3A8A"
        android:pathData="M40,0 L320,0 L280,180 L0,180 Z"/>
    <!-- Didelis trikampis centre -->
    <path
        android:fillColor="#FFFFCC00"
        android:pathData="M130,60 l70,30 l-70,30 z"/>
</vector>

EOF

echo "✍️ Konfigūruojami Gradle nustatymai..."
cat << 'EOF' > settings.gradle
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "TopFilmaiTV"
include ':app'
EOF

cat << 'EOF' > build.gradle
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.1.1'
        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:1.8.10"
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
    }
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
EOF

cat << 'EOF' > gradle.properties
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
EOF

cat << 'EOF' > gradlew
#!/bin/sh
if [ ! -d ".gradle-bin" ]; then
    echo "⬇️ Atsisiunčiama Gradle aplinka (8.1.1)..."
    curl -sL https://services.gradle.org/distributions/gradle-8.1.1-bin.zip -o gradle.zip
    unzip -q gradle.zip
    rm gradle.zip
    mv gradle-8.1.1 .gradle-bin
    chmod +x .gradle-bin/bin/gradle
fi
exec ./.gradle-bin/bin/gradle "\$@"
EOF
chmod +x gradlew

cat << 'EOF' > gradlew.bat
@echo off
if not exist .gradle-bin (
    echo Atsisiunciama Gradle aplinka...
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest https://services.gradle.org/distributions/gradle-8.1.1-bin.zip -OutFile gradle.zip"
    powershell -Command "Expand-Archive -Path gradle.zip -DestinationPath ."
    del gradle.zip
    move gradle-8.1.1 .gradle-bin
)
.gradle-bin\bin\gradle.bat %*
EOF

echo "=========================================================="
echo "🚀 PALEIDŽIAMAS GREITASIS APK KOMPILIAVIMAS..."
echo "⏳ Tai truks kelias dešimtis sekundžių fone. Prašome palaukti..."
echo "=========================================================="

docker run --rm -v "\$PWD":/app -w /app alvrme/alpine-android:latest-sdk34 ./gradlew assembleDebug

if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo ""
    echo "=========================================================="
    echo "🎉 VALIO! APK sėkmingai sukompiliuota jūsų TV priedėliui!"
    echo "📥 Švelnus atsisiuntimas prasideda dabar..."
    echo "=========================================================="
    cloudshell download app/build/outputs/apk/debug/app-debug.apk
else
    echo ""
    echo "⚠️ Docker nenumatyta situacija. Paleidžiame vietinį kompiliatorių fone..."
    export ANDROID_HOME=\$HOME/android-sdk
    if [ ! -d "\$ANDROID_HOME" ]; then
        echo "⬇️ Atsisiunčiame Android SDK cmd tools..."
        mkdir -p \$ANDROID_HOME/cmdline-tools
        curl -sL https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -o sdk.zip
        unzip -q sdk.zip -d \$ANDROID_HOME/cmdline-tools
        rm sdk.zip
        mv \$ANDROID_HOME/cmdline-tools/cmdline-tools \$ANDROID_HOME/cmdline-tools/latest
    fi
    yes | \$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --licenses --sdk_root=\$ANDROID_HOME > /dev/null
    ./gradlew assembleDebug --no-daemon
    if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
        echo "🎉 SĖKMĖ per antrinę sistemą!"
        cloudshell download app/build/outputs/apk/debug/app-debug.apk
    else
        echo "❌ Abi kompiliavimo strategijos susidūrė su kliūtimis. Prašome naudoti standartinę Android Studio."
    fi
fi
